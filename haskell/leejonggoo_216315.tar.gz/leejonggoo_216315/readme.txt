1 ~ 5번까지 완성

5번은 쉘에서 "runghc project5.hs" 로 수행
